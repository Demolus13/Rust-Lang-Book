// TODO: Add some function with the name `call_me` without arguments or a return value.
fn call_me() {
    println!("Hello, World!")
}

fn main() {
    call_me(); // Don't change this line
}
