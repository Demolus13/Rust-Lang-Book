fn main() {
    // TODO: Add the missing keyword.
    let x = 5;

    println!("x has the value {x}");
}
