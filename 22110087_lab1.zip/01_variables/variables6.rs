// TODO: Change the line below to fix the compiler error.
const NUMBER: i32 = 3;

fn main() {
    println!("Number: {NUMBER}");
}
